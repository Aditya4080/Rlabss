﻿using JWTAuth.Models;
using System;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Mvc;
using JWTAuth.Repository;
using System.IO;
using System.Web;

namespace JWTAuth.Controllers
{
    public class AccountController : Controller
    {
        EmployeeRepository objemp;
        public ActionResult Index()
        {
            return View();
        }

        // POST: /account/login
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(AccountLoginModel viewModel)
        {
            try
            {
                if (!ModelState.IsValid)
                    return View("index", viewModel);

                objemp = new EmployeeRepository();
                RegistrationModel Registration = new RegistrationModel();
                Registration.Email = viewModel.Email;
                Registration.Password = viewModel.Password;
                objemp.GetEmployee(Registration);

                
                
                if (Registration.Password.Equals(viewModel.Password) && Registration.Email.Equals(viewModel.Email))
                {
                    var roles = new string[] { "SuperAdmin", "Admin" };
                    var jwtSecurityToken = Authentication.GenerateJwtToken(Registration.Email, roles.ToList());
                    Session["LoginedIn"] = Registration.Email;
                    var validUserName = Authentication.ValidateToken(jwtSecurityToken);
                    return RedirectToAction("index", "Home", new { token = jwtSecurityToken });

                }

                ModelState.AddModelError("", "Invalid username or password.");

            }
            catch (Exception e)
            {
                ModelState.AddModelError("", "Invalid username or password.");
            }
            return View("Index", viewModel);
        }


        public ActionResult Registration()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> RegistrationSubmit(RegistrationModel Registration)
        {
            if (!ModelState.IsValid)
                return View("Registration", Registration);
            objemp = new EmployeeRepository();
            Registration.Photo = TempData["name"].ToString();
            int nonquery = Convert.ToInt32(objemp.AddUpdateEmployee(Registration));
            return RedirectToAction("Registration", "Account");
            
        }

        [HttpPost]
        public ActionResult UploadFiles()
        {
            // Checking no of files injected in Request object  
            if (Request.Files.Count > 0)
            {
                try
                {
                    //  Get all files from Request object  
                    HttpFileCollectionBase files = Request.Files;
                    for (int i = 0; i < files.Count; i++)
                    {
                        //string path = AppDomain.CurrentDomain.BaseDirectory + "Uploads/";  
                        //string filename = Path.GetFileName(Request.Files[i].FileName);  

                        HttpPostedFileBase file = files[i];
                        string fname;

                        // Checking for Internet Explorer  
                        if (Request.Browser.Browser.ToUpper() == "IE" || Request.Browser.Browser.ToUpper() == "INTERNETEXPLORER")
                        {
                            string[] testfiles = file.FileName.Split(new char[] { '\\' });
                            fname = testfiles[testfiles.Length - 1];
                        }
                        else
                        {
                            fname = file.FileName;
                        }

                        // Get the complete folder path and store the file inside it.  
                        fname = Path.Combine(Server.MapPath("~/upload/"), fname);
                        file.SaveAs(fname);
                        TempData["name"] = file.FileName;
                    }
                    // Returns message that successfully uploaded  
                    return Json("File Uploaded Successfully!");
                }
                catch (Exception ex)
                {
                    return Json("Error occurred. Error details: " + ex.Message);
                }
            }
            else
            {
                return Json("No files selected.");
            }
        }

    }
}