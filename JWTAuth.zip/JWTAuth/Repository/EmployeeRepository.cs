﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using JWTAuth.Models;

namespace JWTAuth.Repository
{
    public class EmployeeRepository
    {
        string connStr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;

        public int AddUpdateEmployee(RegistrationModel em)
        {
            using (var con = new SqlConnection(connStr))
            {
                try
                {
                    SqlCommand cmd;
                    con.Open();
                    cmd = new SqlCommand("Employee_InsertUpdate", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Name", em.Name);
                    cmd.Parameters.AddWithValue("@Email", em.Email);
                    cmd.Parameters.AddWithValue("@Password", em.Password);
                    cmd.Parameters.AddWithValue("@Photo", em.Photo);
                    cmd.Parameters.AddWithValue("@Action", "I");
                    int i= cmd.ExecuteNonQuery();
                    con.Close();
                    return i;
                }
                catch (Exception ex)
                {

                    throw;
                }

            }

        }

        public RegistrationModel GetEmployee(RegistrationModel em)
        {
            try
            {
                using (var con = new SqlConnection(connStr))
                {
                     
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Employee_InsertUpdate", con);
                    cmd.Parameters.AddWithValue("@Email", em.Email);
                    cmd.Parameters.AddWithValue("@Password", em.Password);
                    cmd.Parameters.AddWithValue("@Action","R");
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        em.Name =  dr["Email"].ToString() ;
                        em.Password = Convert.ToString(dr["Password"]);
                       
                    }
                    con.Close();
                    return em;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

    }
}